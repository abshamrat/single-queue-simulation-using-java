package single_channel_q;

import java.text.DecimalFormat;
import java.util.Random;
import java.util.Scanner;

public class Simulation {
	
	private String[] ST_COLUMN_HEAD = {"Customer","Time Since LA(mins)","Arrival Time","Service Time(mins)","Time Service Begins","Time C. Wait in Q(mins)","Time Service Ends","Time Customer Spends in System(mins)","Idle Time of server(mins)"};
	private String[] TA_COLUMN = {"Time Btn Arrival(mins)","Probability","C. Probability","Random Digits Assignment"};
	private String[] SA_COLUMN = {"Service Time(mins)","Probability","C. Probability","Random Digits Assignment"};
	
	private double Clock = 0;
	private double Accumulator = 0;
	private int MaxQLength = 0;
	private int CUSTOMER_NO = 100;
	private int TIME_BTN_ARRIVAL_LIMIT = 12;
	private int SERVICE_TIME_LIMIT = 10;
	
	private String[][] arrivalTable = new String[TIME_BTN_ARRIVAL_LIMIT][4];
	private String[][] serviceTable = new String[SERVICE_TIME_LIMIT][4];
	private String[][] simulationTable = new String[CUSTOMER_NO][9];
	private Random rand = new Random();
	private double CumPro = 0;
	private int randDigit=1;
	private double SServiceTime = 0;
	private double SWaitingTime = 0;
	private double SIdleTime = 0;
	private double SWCustomer = 0;
	private double STimeSpends = 0;
	private double probability[] = new double[TIME_BTN_ARRIVAL_LIMIT];
	private DecimalFormat df = new DecimalFormat("#.##");
	private DecimalFormat dfr = new DecimalFormat("#.####");
	
	public Simulation() {
		// TODO Auto-generated constructor stub
		initialize();
	}
	private void initialize(){
		takeInput();
		System.out.println("\n-------------------------Simulation Started----------------------------------------------");
		timeBtnArrivalTable();
		System.out.println("-----------------------------------------------------------------------");
		serviceTimeTable();
		System.out.println("-----------------------------------------------------------------------");
		simulationTable();
		generateReport();
		
	}
	public void takeInput(){
		System.out.println("\n---------------------------Single Channel Queue System---------------------------------------\n");
		System.out.print("Enter Time Between Arrival Limit: ");
		Scanner sc = new Scanner(System.in);
		TIME_BTN_ARRIVAL_LIMIT = sc.nextInt();
		System.out.print("\nEnter Service Time Limit: ");
		SERVICE_TIME_LIMIT = sc.nextInt();
		System.out.print("\nEnter Number of Customer: ");
		CUSTOMER_NO = sc.nextInt();
	}
	public void timeBtnArrivalTable(){
		
		probability = getProbabilityArray(TIME_BTN_ARRIVAL_LIMIT);
		System.out.println(TA_COLUMN[0]+" | "+TA_COLUMN[1]+" | "+TA_COLUMN[2]+" | "+TA_COLUMN[3]);
		for (int i = 0; i < TIME_BTN_ARRIVAL_LIMIT; i++) {
			
			String pb = df.format(probability[i]);
			CumPro = CumPro+Double.parseDouble(df.format(probability[i]));
			arrivalTable[i][0]=new Integer(i+1).toString();
			arrivalTable[i][1] = pb;
			arrivalTable[i][2] = df.format(CumPro);
			arrivalTable[i][3] = ""+randDigit+"-"+ (int)(CumPro*100);
			randDigit = 1+(int)(CumPro*100);
			
			System.out.println(arrivalTable[i][0]+"                      | "+arrivalTable[i][1]+"                | "+arrivalTable[i][2]+"        | "+arrivalTable[i][3]);
			
		}
	}
	public void serviceTimeTable(){
		CumPro = 0;
		randDigit=1;
		probability = getProbabilityArray(SERVICE_TIME_LIMIT);
		
		System.out.println(SA_COLUMN[0]+" | "+SA_COLUMN[1]+" | "+SA_COLUMN[2]+" | "+SA_COLUMN[3]);
		for (int i = 0; i < SERVICE_TIME_LIMIT; i++) {
			
			String pb = df.format(probability[i]);
			CumPro = CumPro+Double.parseDouble(df.format(probability[i]));
			serviceTable[i][0]=new Integer(i+1).toString();
			serviceTable[i][1] = pb;
			serviceTable[i][2] = df.format(CumPro);
			serviceTable[i][3] = ""+randDigit+"-"+ (int)(CumPro*100);
			randDigit = 1+(int)(CumPro*100);
			System.out.println(serviceTable[i][0]+"                  | "+serviceTable[i][1]+"                | "+serviceTable[i][2]+"        | "+serviceTable[i][3]);
			
		}
	}
	public void simulationTable(){
		Random sRand = new Random();
		Random tRand = new Random();
		
		int srMax = 100; 
		int trMax = 100;
		double CumPro = 0;
		int randDigit=1;
		
		int aTime = 0;
		
		DecimalFormat df = new DecimalFormat("#.##");
		
		System.out.println(ST_COLUMN_HEAD[0]+" | RD"+" | "+ST_COLUMN_HEAD[1]+" | "+ST_COLUMN_HEAD[2]+" | RD | "+ST_COLUMN_HEAD[3]+" | "+ST_COLUMN_HEAD[4]+" | "+ST_COLUMN_HEAD[5]+" | "+ST_COLUMN_HEAD[6]+" | "+ST_COLUMN_HEAD[7]+" | "+ST_COLUMN_HEAD[8]);
		for (int i = 0; i <CUSTOMER_NO; i++) {
			double trd = tRand.nextInt(trMax);
			double srd = sRand.nextInt(srMax);
			int tsla = getArrivalTimeByRD(new Integer((int) trd));
			int st = getServiceTimeByRD(new Integer((int) srd));
			simulationTable[i][0]=new Integer(i+1).toString();
			if(i > 0){
				aTime = aTime + tsla;
				simulationTable[i][1]=new Integer(tsla).toString();
				simulationTable[i][2]=new Integer(aTime).toString();
				simulationTable[i][3]=new Integer(st).toString();
				if(aTime<new Integer(simulationTable[i-1][6])){
					simulationTable[i][4]=simulationTable[i-1][6];
					simulationTable[i][5]=""+(new Integer(simulationTable[i-1][6])-aTime);
				}
				else{
					simulationTable[i][4]=""+aTime;
					simulationTable[i][5]="0";
				}
				simulationTable[i][6]=""+(new Integer(simulationTable[i][4])+new Integer(simulationTable[i][3]));
				simulationTable[i][7]=""+((new Integer(simulationTable[i][6])-new Integer(simulationTable[i][4])+new Integer(simulationTable[i][5])));
				simulationTable[i][8]=""+(new Integer(simulationTable[i][4])-new Integer(simulationTable[i-1][6]));
				
			}
			else{
				simulationTable[i][1]="0";
				simulationTable[i][2]="0";
				simulationTable[i][3]=new Integer(st).toString();
				simulationTable[i][4]="0";
				simulationTable[i][5]="0";
				simulationTable[i][6]=new Integer(st).toString();
				simulationTable[i][7]=new Integer(st).toString();
				simulationTable[i][8]="0";
				
			}
			SServiceTime = SServiceTime+ new Double(simulationTable[i][3]);
			SWaitingTime = SWaitingTime+new Double(simulationTable[i][5]);
			SIdleTime = SIdleTime+new Double(simulationTable[i][8]);
			STimeSpends = STimeSpends+new Double(simulationTable[i][7]);
			if(new Integer(simulationTable[i][5]) != 0){SWCustomer++;}
			
			System.out.println(simulationTable[i][0]+"        | "+trd+" |        "+simulationTable[i][1]+"          |     "+simulationTable[i][2]+"      | "+srd+" |    "+simulationTable[i][3]+"                  | "+simulationTable[i][4]+"                   | "+simulationTable[i][5]+"                   | "+simulationTable[i][6]+"                   | "+simulationTable[i][7]+"                                     | "+simulationTable[i][8]);
			
		}
	}
	public void generateReport(){
		System.out.println("\n------------------------------Simulation Report----------------------------------\n");
		System.out.println("Aerage Waiting Time: "+dfr.format(SWaitingTime/CUSTOMER_NO));	
		System.out.println("Probability that a customer has to wait: "+dfr.format(SWaitingTime/CUSTOMER_NO));
		System.out.println("Aerage Service Time: "+dfr.format(SServiceTime/CUSTOMER_NO));
		System.out.println("Probability of Idle time of server: "+dfr.format(SIdleTime/new Integer(simulationTable[CUSTOMER_NO-1][6])));
		System.out.println("Aerage Time Between Arrival: "+dfr.format(new Integer(simulationTable[CUSTOMER_NO-1][2])/(CUSTOMER_NO-1)));
		System.out.println("Aerage Time Customer Spends in System: "+dfr.format(STimeSpends/CUSTOMER_NO));
	}
	public int getArrivalTimeByRD(int rd){
		
		
		for (int i = 0; i <TIME_BTN_ARRIVAL_LIMIT; i++) {
			int min = new Integer(arrivalTable[i][3].split("-")[0]);
			int max = new Integer(arrivalTable[i][3].split("-")[1]);
			if( rd >= min  && rd <= max)
			{
				return new Integer(arrivalTable[i][0]);
			}
		}
		
		
		return 0;
	}
	public int getServiceTimeByRD(int rd){
		
		
		for (int i = 0; i <SERVICE_TIME_LIMIT; i++) {
			int min = new Integer(serviceTable[i][3].split("-")[0]);
			int max = new Integer(serviceTable[i][3].split("-")[1]);
			if( rd >= min  && rd <= max)
			{
				return new Integer(serviceTable[i][0]);
			}
		}
		
		return 0;

	}
	public double[] getProbabilityArray(int n)
    {
        double a[] = new double[n];
        double s = 0.0d;
        Random random = new Random();
        for (int i = 0; i < n; i++)
        {
           a [i] = 1.0d - random.nextDouble();
           a [i] = -1 * Math.log(a[i]);
           
           s += a[i];
           
        }
     
        for (int i = 0; i < n; i++)
        {
           a [i] /= s;
        }
        return a;
    }
}
